import { Component, OnInit, Input } from '@angular/core';
import { CreateModalContentComponent } from '../create-modal-content/create-modal-content.component';

@Component({
  selector: 'app-my-tasks',
  templateUrl: './my-tasks.component.html',
  styleUrls: ['./my-tasks.component.css']
})
export class MyTasksComponent implements OnInit {
  @Input() modal_content:CreateModalContentComponent;
  taskList:any[];
  constructor() { 
    this.taskList=CreateModalContentComponent.prototype.taskList;
    console.log(this.taskList);
  }

  ngOnInit() {


  }


}
