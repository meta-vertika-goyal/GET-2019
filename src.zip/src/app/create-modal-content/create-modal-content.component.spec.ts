import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateModalContentComponent } from './create-modal-content.component';

describe('CreateModalContentComponent', () => {
  let component: CreateModalContentComponent;
  let fixture: ComponentFixture<CreateModalContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateModalContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateModalContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
