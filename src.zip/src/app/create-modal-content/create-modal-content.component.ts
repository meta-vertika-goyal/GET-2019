import { Component, OnInit } from '@angular/core';
import { NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-create-modal-content',
  templateUrl: './create-modal-content.component.html',
  styleUrls: ['./create-modal-content.component.css']
})
export class CreateModalContentComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal) {}

  ngOnInit() {
  }

}
